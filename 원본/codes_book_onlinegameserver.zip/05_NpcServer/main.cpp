#include "stdafx.h"

int main()
{
	return 0;
}